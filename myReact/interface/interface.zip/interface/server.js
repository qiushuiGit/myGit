// 想学 node 可以下载 44期js的实战项目 （风屿老师）
// 不能用6000端口
const Koa = require('koa')
const Router = require('koa-router')
const cors = require('kcors')
const app = new Koa()

const router = new Router()


app.use(cors())
app.use(require('koa-static')(__dirname+'/static/images'))

const homeCateData = require('./home/category')
router.get('/api/category',function (ctx) {
    ctx.body = homeCateData
})


app.use(router.routes()).use(router.allowedMethods())

app.listen(6006,function () {
    console.log('node启动成功')
})