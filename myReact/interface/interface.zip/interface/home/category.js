const data = [
    {
        img: 'http://47.100.98.54:6000/category/1.png',
        title: '美食'
    },
    {
        img: 'http://47.100.98.54:6000/category/2.png',
        title: '甜品饮品'
    }
]

module.exports = data