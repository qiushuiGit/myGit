const imgPromotion = [
        {
            img: "http://47.99.201.114:6006/promotion/promotion1.png",
            id: "0"
        },
        {
            img: "http://47.99.201.114:6006/promotion/promotion2.png",

            id: "1"
        },
        {
            img: "http://47.99.201.114:6006/promotion/promotion3.png",

            id: "2"
        },
        {
            img: "http://47.99.201.114:6006/promotion/promotion4.png",

            id: "3"
        }

    ]

module.exports = imgPromotion