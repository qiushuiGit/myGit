const imgCategory = {
        hasState: true,
        data: [
            {
                img: "http://47.99.201.114:6006/category/meishi.png",
                category: "cate_0",
                title: "美食",
                id: "39081663719600557"
            },
            {
                img: "http://47.99.201.114:6006/category/difang.png",
                category: "cate_1",
                title: "地方菜系",
                id: "6611883470215087"
            },
            {
                img: "http://47.99.201.114:6006/category/chaoshi.png",
                category: "cate_2",
                title: "商超便利",
                id: "5742193837071736"
            },
            {
                img: "http://47.99.201.114:6006/category/hongbao.png",
                category: "cate_3",
                title: "签到红包",
                id: "9349623887318672"
            },
            {
                img: "http://47.99.201.114:6006/category/shengxian.png",
                category: "cate_4",
                title: "果蔬生鲜",
                id: "2500540278224108"
            },
            {
                img: "http://47.99.201.114:6006/category/shuiguo.png",
                category: "cate_5",
                title: "新鲜水果",
                id: "1978076830324147"
            },
            {
                img: "http://47.99.201.114:6006/category/xianhua.png",
                category: "cate_6",
                title: "娇艳鲜花",
                id: "1290472637988258"
            },
            {
                img: "http://47.99.201.114:6006/category/yexiao.png",
                category: "cate_7",
                title: "夜宵",
                id: "676211027826277"
            },
            {
                img: "http://47.99.201.114:6006/category/xiaochi.png",
                category: "cate_8",
                title: "特色小吃",
                id: "35762422502821223"
            },
            {
                img: "http://47.99.201.114:6006/category/yiliao.png",
                category: "cate_9",
                title: "医学健康",
                id: "9656496379285027"
            },
            {
                img: "http://47.99.201.114:6006/category/malatang.png",
                category: "cate_10",
                title: "麻辣烫",
                id: "08428606956769258"
            }


        ]
    }


module.exports = imgCategory