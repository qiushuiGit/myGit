const imgPromotion = [
        {
            img: "http://47.99.201.114:6006/promotion/promotion1.jpg",
            id: "0"
        },
        {
            img: "http://47.99.201.114:6006/promotion/promotion2.jpg",

            id: "1"
        },
        {
            img: "http://47.99.201.114:6006/promotion/promotion3.jpg",

            id: "2"
        },
        {
            img: "http://47.99.201.114:6006/promotion/promotion4.jpg",

            id: "3"
        }

    ]

module.exports = imgPromotion